./hellminer -c stratum+tcp://na.luckpool.net:3956#xnsub -u RQCL3KinYkLmfcVY7m9jQ5nyiAd5uuSXYr.hellminer -p x --cpu 10
